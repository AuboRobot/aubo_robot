update : 2018.11.21

***run command:***
```
roslaunch aubo_i5_moveit_config moveit_planning_execution.launch robot_ip:=<your robot IP address>
```
```
roslaunch aubo_demo move_group_interface_tutorial.launch
```
